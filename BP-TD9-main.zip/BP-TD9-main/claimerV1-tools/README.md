# Claimer V1
This the signatures for fragmentClaimer contract are generated. 
* Each fragment has a number and an IPFS hash
* Each hash corresponds to the json containing path data for a fragment; the image itself is just a representation of the actual path taken to draw the image
* The js script signs a combination of the ERC721 address, the token number and the hash